from django.apps import AppConfig


class SruAppConfig(AppConfig):
    name = 'sru_app'
