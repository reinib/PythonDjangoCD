from django.apps import AppConfig


class LogRegsAppConfig(AppConfig):
    name = 'log_regs_app'
